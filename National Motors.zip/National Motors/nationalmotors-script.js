/*
* Theresa Kincaid
* CS-499 Computer Science Capstone, Prof Brooke
* Southern New Hampshire University

* Category Three: Database (Part 2)

* This program connects to a MongoDB server.
* This program uses the MongoDB Node.js driver to interact the "nationalmotors" database.
* This program includes the logic to perform operations on the "sales" collection of the database.
  --> Search: The program searchs for Month 1.
  --> Enter: The program enters a sales records for Month 29.
  --> Update: The program updates Month 1.
  --> Delete: The program deletes Month 2.
* After the program performs an operation, it closes the connection to the server.
* To change the selected option, modify the "selectedOption" variable.
*/

// Establish a connection to MongoDB server
const { MongoClient } = require("mongodb");

// Connection URL and database name
const url = "mongodb+srv://theresakincaid:nationalmotorsdatabase@nationalmotors.wgkqoyp.mongodb.net/";
const dbName = "nationalmotors";

// Function to handle menu options
async function handleMenuChoice(selectedOption) {
  switch (selectedOption) {
    case "Search":
      await performSearch();
      break;
    case "Enter":
      await performInsertion();
      break;
    case "Update":
      await performUpdate();
      break;
    case "Delete":
      await performDeletion();
      break;
    default:
      console.log("Invalid option");
  }
}

// Function to perform search
async function performSearch() {
  // establish connection to database
  const client = await MongoClient.connect(url);
  try {
    console.log("Connected successfully to MongoDB");
    const db = client.db(dbName);
    const collection = db.collection("sales");
    // find records where Month = 1, log search results
    const query = { Month: "1" };
    const result = await collection.find(query).toArray();
    console.log("Search result:", result);
  }
  // handle errors
  catch (err) {
    console.error("Error performing search", err);
  }
  // close connection to database
  finally {
    client.close();
  }
}

// Function to perform insertion
async function performInsertion() {
  // establish connection to database
  const client = await MongoClient.connect(url);
  try {
    console.log("Connected successfully to MongoDB");
    const db = client.db(dbName);
    const collection = db.collection("sales");
    // new record to insert
    const document = {
      "Month": "29",
      "Kansas City": "4050",
      "Chicago": "2550",
      "Houston": "3800",
      "Oklahoma City": "15000",
      "Omaha": "5210",
      "Little Rock": "5010",
    };
    // log insert results
    const result = await collection.insertOne(document);
    console.log("Insertion result:", result);
  }
  // handle errors
  catch (err) {
    console.error("Error performing insertion", err);
  }
  // close connection to database
  finally {
    client.close();
  }
}

// Function to perform update
async function performUpdate() {
  // establish connection to database
  const client = await MongoClient.connect(url);
  try {
    console.log("Connected successfully to MongoDB");
    const db = client.db(dbName);
    const collection = db.collection("sales");
    // update records with Month = 1
    const filter = { Month: "1" };
    // enter new values
    const update = {
      $set: {
        "Kansas City": "3500",
        "Chicago": "2200",
        "Houston": "4010",
        "Oklahoma City": "14510",
        "Omaha": "5000",
        "Little Rock": "4860",
      },
    };
    // log update results
    const result = await collection.updateMany(filter, update);
    console.log("Update result:", result);
  }
  // handle errors
  catch (err) {
    console.error("Error performing update", err);
  }
  // close connection to database
  finally {
    client.close();
  }
}

// Function to perform deletion
async function performDeletion() {
  const client = await MongoClient.connect(url);
  // establish connection to database
  try {
    console.log("Connected successfully to MongoDB");
    const db = client.db(dbName);
    const collection = db.collection("sales");
    // delete records where Month = 2, log deletion results
    const filter = { Month: "2" };
    const result = await collection.deleteMany(filter);
    console.log("Deletion result:", result);
  }
  // handle errors
  catch (err) {
    console.error("Error performing deletion", err);
  }
  // close connection to database
  finally {
    client.close();
  }
}

// Change variable to perfrom different operation: Search, Enter, Update, Delete
const selectedOption = "Search";
handleMenuChoice(selectedOption);