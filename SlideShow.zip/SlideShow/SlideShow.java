/*
* Theresa Kincaid
* CS-499 Computer Science Capstone, Prof Brooke
* Southern New Hampshire University

* Category One: Sotware Design/Engineering

* This program implements a slideshow application using Java Swing.
* The slideshow displays six slides with images and text descriptions.
* The slideshow has a timer to automatically advance to the next slide.
* The user can navigate through the slides using the following buttons:
	--> Restart (btnFirst): restarts the slideshow.
	--> Previous (btnPrev): navigates to the previous slide.
	--> Next (btnNext): navigates to the next slide.
	--> Pause/Resume (btnPause): pause or resume the slideshow.
*/

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.EventQueue;
import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.Timer;

public class SlideShow extends JFrame {
	
	// Declare Variables
	private JPanel slidePane; // panes
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card; // navigation
	private CardLayout cardText;
	private JLabel lblSlide; // labels
	private JLabel lblTextArea;
	private JButton btnFirst; // First/Restart button
	private JButton btnPrev; // Previous button
	private JButton btnNext; // Next button
	private JButton btnPause; // Pause/Resume button
	private Timer timer; // timer
	private boolean paused; // variable to track pause state
	// Create the application
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	// Initialize the contents of the frame
	private void initComponent() {
		
		// Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		slidePane.setBackground(Color.WHITE); // slide background
		textPane = new JPanel();
		textPane.setBackground(Color.WHITE); // text description background
		textPane.setBounds(5, 470, 700, 60); // moves and resizes text
		textPane.setVisible(true);
		lblSlide = new JLabel();
		lblTextArea = new JLabel();
		buttonPane = new JPanel();
		btnFirst = new JButton(); // Restart button
		btnPrev = new JButton(); // Previous button
		btnNext = new JButton(); // Next button
		btnPause = new JButton(); // Pause/Resume button

		// Setup frame attributes
		setSize(700, 600);
		setLocationRelativeTo(null);
		setTitle("SNHU Travel SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // close application when user closes window

		// Set the layout for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		// Add each of the slides and text
		for (int i = 1; i <= 6; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}
		
		// Position panes
		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);
		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
		
		// Setup timer, 3 seconds for each slide
		timer = new Timer(3000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		timer.start(); // start timer
		
		// Restart button
		btnFirst.setText("Restart");
		btnFirst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goFirst();
			}
		});
		buttonPane.add(btnFirst);
		
		// Previous slide button
		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);
		
		// Next slide button
		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);
		
		// Resume/Pause button, with functionality
		btnPause.setText("Pause");
		btnPause.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!paused) {
					paused = true; // set paused state
					timer.stop(); // stop timer
					btnPause.setText("Resume"); // change button text
				} else {
					paused = false; // unset paused state
					timer.start(); // start timer
					btnPause.setText("Pause"); // change button text
				}
			}
		});
		buttonPane.add(btnPause);
		getContentPane().add(buttonPane, BorderLayout.SOUTH);  // move buttons to the bottom
	}
	
	// Restart button functionality
	public void goFirst() {
		timer.stop(); // stop timer
		card.first(slidePane);
		cardText.first(textPane);
		timer.restart(); // restart timer
	}
	
	// Previous button functionality
	private void goPrevious() {
		timer.stop(); // stop timer
		card.previous(slidePane);
		cardText.previous(textPane);
		timer.restart(); // restart timer
	}
	
	// Next button functionality
	private void goNext() {
		timer.stop(); // stop timer
		card.next(slidePane);
		cardText.next(textPane);
		timer.restart(); // restart timer
	}
	
	// Get images for each slide
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			image = "<html><body><img width= '700' height='450' src='" + getClass().getResource("/resources/location1.jpg") + "'</body></html>";
		} else if (i==2){
			image = "<html><body><img width= '700' height='450' src='" + getClass().getResource("/resources/location2.jpg") + "'</body></html>";
		} else if (i==3){
			image = "<html><body><img width= '700' height='450' src='" + getClass().getResource("/resources/location3.jpg") + "'</body></html>";
		} else if (i==4){
			image = "<html><body><img width= '700' height='450' src='" + getClass().getResource("/resources/location4.jpg") + "'</body></html>";
			} else if (i==5){
				image = "<html><body><img width= '700' height='450' src='" + getClass().getResource("/resources/location5.jpg") + "'</body></html>";
		} else if (i==6){
			image = "<html><body><img width= '700' height='450' src='" + getClass().getResource("/resources/location6.jpg") + "'</body></html>";
		}
		return image;
	}
	
	// Get text values for each slide
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			text = "<html><body><font size='6'>1. <b>Smith's Wellness Center</b></font> <br><font size='4'>This location has multiple gyms, fitness programs, and personal trainers.</font></body></html>";
		} else if (i==2){
			text = "<html><body><font size='6'>2. <b>Blairstown Yoga & Wellness</b></font> <br><font size='4'>This location provides physical therapy, spa treatments, and yoga classes.</font></body></html>";
		} else if (i==3){
			text = "<html><body><font size='6'>3. <b>Clearview Wellness Center</b></font> <br><font size='4'>This location has a luxury spa, indoor swimming pool, and access to a beautiful gym.</font></body></html>";
		} else if (i==4){
			text = "<html><body><font size='6'>4. <b>Belvidere Recovery</b></font> <br><font size='4'>Peaceful space for addiction recovery and therapy.</font></body></html>";
		} else if (i==5){
			text = "<html><body><font size='6'>5. <b>Spring Valley Rehab</b></font> <br><font size='4'>This location offers inpatient drug recovery programs.</font></body></html>";
		} else if (i==6){
			text = "<html><body><font size='6'>6. <b>S&L Gym</b></font> <br><font size='4'>This gym is located in Hope, New Jersey. Open 24 hours! Free Wifi available to all customers!</font></body></html>";
		}
		return text;
	}
	
	// Launch the application
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}