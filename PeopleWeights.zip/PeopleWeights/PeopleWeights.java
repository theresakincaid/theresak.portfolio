/*
* Theresa Kincaid
* CS-499 Computer Science Capstone, Prof Brooke
* Southern New Hampshire University

* Category Two: Algorithms and Data Structures

* This program provides the user with a menu to manage names and weights:
    -> Option 1: Displays all records, the total number of records, total weight, average weight, maximum weight, and standard deviation.
    -> Option 2: Prompts the user to enter a new name and weight, adds them to the arrays, and updates the calculations.
    -> Option 3: Allows the user to search for a record with a name. If found, it displays the corresponding name and weight.
    -> Option 4: Quits the program.
* Arrays are prepopulated with initial data for five people.
* The program uses Bubble Sort, due to its efficiency with small data sets.
* After each operation, the program returns to the menu, unless the user chooses to quit.
*/

import java.util.Scanner;

public class PeopleWeights {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Declare variables
        final int SIZE = 10;
        double total = 0.0, average = 0.0, max = 0.0;
        int numRecords = 5;
        // Declare arrays
        String[] names = new String[SIZE];
        double[] weights = new double[SIZE];
        double[] deviations = new double[SIZE];

        // Populating the arrays with initial data, five names and five weights
        names[0] = "Mike";
        names[1] = "Mia";
        names[2] = "Joe";
        names[3] = "Frank";
        names[4] = "Sarah";
        weights[0] = 154;
        weights[1] = 137;
        weights[2] = 201;
        weights[3] = 178;
        weights[4] = 152;
        
        // Calculations
        total = weights[0] + weights[1] + weights[2] + weights[3] + weights[4]; // total
        average = total / numRecords; // average
        max = weights[0]; // max
        // standard deviation
        for (int i = 0; i < SIZE; i++) {
            deviations[i] = weights[i] - average;
            if (weights[i] > max) {
                max = weights[i];
            }
        }
        double sumSquares = 0.0;
        for (int i = 0; i < SIZE; i++) {
            sumSquares += deviations[i] * deviations[i];
        }
        double variance = sumSquares / SIZE;
        double stdDeviation = Math.sqrt(variance);
        
        // Menu options for user
        boolean quit = false;
        while (!quit) {
            System.out.println("\nMenu:");
            System.out.println("1. Show all records");
            System.out.println("2. Enter a record");
            System.out.println("3. Search a record");
            System.out.println("4. Quit");
            System.out.print("Enter your choice (1-4): ");
            int choice = input.nextInt();
            input.nextLine();
            
            // Bubble Sort to sort the weights, in ascending order
            for (int i = 0; i < numRecords - 1; i++) {
                for (int j = 0; j < numRecords - i - 1; j++) {
                    if (weights[j] > weights[j + 1]) {
                        // swap weights
                        double temp = weights[j];
                        weights[j] = weights[j + 1];
                        weights[j + 1] = temp;
                        // swap names
                        String tempName = names[j];
                        names[j] = names[j + 1];
                        names[j + 1] = tempName;
                    }
                }
            }
            
            switch (choice) {
                // Option 1: Show all records/calculations
                case 1:
                    System.out.println("\nAll records:");
                    for (int i = 0; i < numRecords; i++) {
                        if (names[i] != null) {
                            if (weights[i] == max) {
                                System.out.println(names[i] + ": " + weights[i]);
                            } 
                            else {
                                System.out.println(names[i] + ": " + weights[i]);
                            }
                        }
                    }
                    System.out.println();
                    System.out.println("Total records: " + numRecords);
                    System.out.println("Total weight: " + total);
                    System.out.println("Average weight: " + average);
                    System.out.println("Max weight: " + max);
                    System.out.println("Standard deviation: " + stdDeviation);
                    break;
                
                // Option 2: Enter record
                case 2:
                    System.out.print("Enter name " + (numRecords + 1) + ": ");
                    names[numRecords] = input.nextLine();
                    System.out.print("Enter weight " + (numRecords + 1) + ": ");
                    weights[numRecords] = input.nextDouble();
                    input.nextLine();
                    // update total and average weight
                    total += weights[numRecords];
                    average = total / (numRecords + 1);
                    // if necessary, update max weight
                    if (weights[numRecords] > max) {
                        max = weights[numRecords];
                    }
                    numRecords++;
                    System.out.println("\nRecord added.");
                    break;
                
                // Option 3: Search record
                case 3:
                    System.out.print("\nEnter name to search (case-sensitive): ");
                    String nameSearch = input.nextLine();
                    // search through records to find match
                    boolean found = false;
                    for (int i = 0; i < numRecords; i++) {
                        // if match is found, display record
                        if (names[i] != null && names[i].equalsIgnoreCase(nameSearch)) {
                            System.out.println(names[i] + ": " + weights[i]);
                            found = true;
                        }
                    }
                    if (!found) {
                        System.out.println("Record not found.");
                    }
                    break;
                
                // Option 4: Quit program
                case 4:
                    quit = true;
                    break;
                
                // Invalid user choice
                default:
                    System.out.println("Invalid choice. Please enter a number 1-4.");
                    break;
            }
        }
        
        input.close();
    }
}